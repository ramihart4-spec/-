const CACHE = 'gharzaldeen-v8';
const OFFLINE_PAGE = '/index.html';

// Install: cache the app
self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE).then(cache => {
      return cache.addAll([
        '/',
        '/index.html',
        '/sw.js'
      ]).catch(() => cache.add('/index.html'));
    })
  );
});

// Activate: clean old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch: cache-first strategy (works offline)
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  
  e.respondWith(
    caches.open(CACHE).then(cache =>
      cache.match(e.request).then(cached => {
        // Return cached version immediately
        if (cached) {
          // Update cache in background
          fetch(e.request).then(resp => {
            if (resp && resp.status === 200) {
              cache.put(e.request, resp.clone());
            }
          }).catch(() => {});
          return cached;
        }
        // Not in cache - try network
        return fetch(e.request).then(resp => {
          if (resp && resp.status === 200) {
            cache.put(e.request, resp.clone());
          }
          return resp;
        }).catch(() => {
          // Network failed - return cached app
          return cache.match(OFFLINE_PAGE);
        });
      })
    )
  );
});
